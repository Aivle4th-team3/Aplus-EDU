from langchain_community.vectorstores import Chroma


def VectorStoreBuilder(embeddings_model):
    stores = {}

    def inner(name):
        print(name, stores)
        if name not in stores:
            print("not in")
            db = Chroma(
                persist_directory="./db/chromadb2",
                embedding_function=embeddings_model,
                collection_name=name,
            )
            stores[name] = db
        print(stores[name])
        return stores[name]
    return inner

    # def add(self, name, text):
    #     if name not in self.stores:
    #         db = Chroma(
    #             persist_directory="./db/chromadb2",
    #             embedding_function=self.embeddings_model,
    #             collection_name=name,
    #         )
    #         self.stores[name] = db

    #     self.stores[name].add_texts(text)
    #     return self.stores[name]

    # def get(self, name):
    #     if name not in self.stores:
    #         db = Chroma(
    #             persist_directory="./db/chromadb2",
    #             embedding_function=self.embeddings_model,
    #             collection_name=name,
    #         )
    #         self.stores[name] = db

    #     return self.stores[name]


